package com.example.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiProviderId
import com.example.data.model.AiProviders
import com.example.ui.chat.components.ChatInputBar
import com.example.ui.chat.components.MessageItem
import com.example.ui.chat.components.ProviderSelectorBar
import com.example.ui.history.HistoryDrawerContent
import com.example.ui.settings.ApiKeySettingsDialog
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate800
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }

    val conversations by viewModel.conversations.collectAsState()
    val currentConvId by viewModel.currentConversationId.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val activeProvider by viewModel.activeProvider.collectAsState()
    val activeModel by viewModel.activeModel.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val attachedFile by viewModel.attachedFile.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var settingsInitialProvider by remember { mutableStateOf(activeProvider) }

    val currentConversation = remember(conversations, currentConvId) {
        conversations.firstOrNull { it.id == currentConvId }
    }

    val activeConfig = AiProviders.get(activeProvider)
    val listState = rememberLazyListState()

    // Scroll to latest message on new message or loading state change
    LaunchedEffect(messages.size, isLoading) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Show toast message in snackbar if available
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(320.dp)) {
                HistoryDrawerContent(
                    conversations = conversations,
                    currentConversationId = currentConvId,
                    onSelectConversation = { id ->
                        viewModel.selectConversation(id)
                    },
                    onNewChat = {
                        viewModel.startNewConversation()
                    },
                    onRenameConversation = { id, title ->
                        viewModel.renameConversation(id, title)
                    },
                    onDeleteConversation = { id ->
                        viewModel.deleteConversation(id)
                    },
                    onClearAllHistory = {
                        viewModel.clearAllHistory()
                    },
                    onCloseDrawer = {
                        coroutineScope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentConversation?.title ?: "OmniAI Chat",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${activeConfig.displayName} • $activeModel",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("open_history_button")
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = "Buka Riwayat")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.startNewConversation() },
                            modifier = Modifier.testTag("new_chat_top_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Chat Baru")
                        }
                        IconButton(
                            onClick = {
                                settingsInitialProvider = activeProvider
                                showSettingsDialog = true
                            },
                            modifier = Modifier.testTag("open_settings_button")
                        ) {
                            Icon(Icons.Default.Key, contentDescription = "Pengaturan API Key")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                ChatInputBar(
                    providerDisplayName = activeConfig.displayName,
                    isLoading = isLoading,
                    attachedFile = attachedFile,
                    onAttachFile = { file -> viewModel.setAttachedFile(file) },
                    onRemoveAttachment = { viewModel.removeAttachment() },
                    onSendMessage = { text ->
                        viewModel.sendMessage(text)
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Provider Selector Bar
                ProviderSelectorBar(
                    activeProvider = activeProvider,
                    activeModel = activeModel,
                    preferences = viewModel.preferences,
                    onSelectProvider = { providerId ->
                        viewModel.setProvider(providerId)
                    },
                    onSelectModel = { model ->
                        viewModel.setModel(model)
                    },
                    onOpenSettingsForProvider = { providerId ->
                        settingsInitialProvider = providerId
                        showSettingsDialog = true
                    }
                )

                // Chat Messages Area
                if (messages.isEmpty()) {
                    EmptyChatWelcome(
                        activeProvider = activeConfig.displayName,
                        hasApiKey = viewModel.preferences.hasApiKey(activeProvider),
                        onOpenSettings = {
                            settingsInitialProvider = activeProvider
                            showSettingsDialog = true
                        },
                        onStarterClicked = { starter ->
                            viewModel.sendMessage(starter)
                        }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            MessageItem(
                                message = msg,
                                onDelete = { viewModel.deleteMessage(msg) }
                            )
                        }

                        if (isLoading) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                    Text(
                                        text = "${activeConfig.displayName} sedang berpikir...",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Slate500,
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        ApiKeySettingsDialog(
            preferences = viewModel.preferences,
            initialProvider = settingsInitialProvider,
            onDismiss = { showSettingsDialog = false },
            onSaveAndApply = { provider, model ->
                viewModel.setProvider(provider)
                viewModel.setModel(model)
                showSettingsDialog = false
            },
            onTestApiKey = { provider, key, model, endpoint ->
                viewModel.testApiKey(provider, key, model, endpoint)
            }
        )
    }
}

@Composable
private fun EmptyChatWelcome(
    activeProvider: String,
    hasApiKey: Boolean,
    onOpenSettings: () -> Unit,
    onStarterClicked: (String) -> Unit
) {
    val starters = listOf(
        "💡 Berikan ringkasan materi penting hari ini",
        "💻 Tulis contoh kode Kotlin Jetpack Compose",
        "✍️ Buat draf pesan profesional dan santun",
        "🧠 Brainstorming 3 ide kreatif untuk proyek saya"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.SmartToy,
                contentDescription = null,
                modifier = Modifier.size(36.dp),
                tint = Slate800
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Siap berdiskusi dengan $activeProvider",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Ketik pertanyaanmu di bawah atau pilih saran cepat.",
            style = MaterialTheme.typography.bodySmall.copy(color = Slate500),
            textAlign = TextAlign.Center
        )

        if (!hasApiKey) {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenSettings)
                    .testTag("setup_key_banner")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Key,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Kunci API belum diisi",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Ketuk di sini untuk memasukkan API Key $activeProvider agar dapat mulai chat.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate500, fontSize = 11.sp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Starter suggestions
        Text(
            "SARAN PERTANYAAN CEPAT",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = Slate400,
                fontSize = 11.sp
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            starters.forEach { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStarterClicked(item.substringAfter(" ")) }
                        .testTag("starter_item"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = item,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}
