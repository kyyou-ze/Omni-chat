package com.example.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ApiKeyPreferences
import com.example.data.local.AppDatabase
import com.example.data.model.AiProviderId
import com.example.data.model.AttachedFile
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    val preferences = ApiKeyPreferences(application)
    val repository = ChatRepository(
        conversationDao = database.conversationDao(),
        messageDao = database.messageDao(),
        preferences = preferences
    )

    val conversations: StateFlow<List<Conversation>> = repository.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<ChatMessage>> = _currentConversationId.flatMapLatest { id ->
        if (id != null) {
            repository.getMessages(id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeProvider = MutableStateFlow(preferences.getActiveProvider())
    val activeProvider: StateFlow<AiProviderId> = _activeProvider.asStateFlow()

    private val _activeModel = MutableStateFlow(preferences.getModel(_activeProvider.value))
    val activeModel: StateFlow<String> = _activeModel.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _attachedFile = MutableStateFlow<AttachedFile?>(null)
    val attachedFile: StateFlow<AttachedFile?> = _attachedFile.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        viewModelScope.launch {
            conversations.collect { list ->
                if (_currentConversationId.value == null && list.isNotEmpty()) {
                    _currentConversationId.value = list.first().id
                }
            }
        }
    }

    fun selectConversation(id: String) {
        _currentConversationId.value = id
    }

    fun startNewConversation() {
        viewModelScope.launch {
            val newConv = repository.createNewConversation(
                provider = _activeProvider.value,
                model = _activeModel.value,
                title = "Percakapan Baru"
            )
            _currentConversationId.value = newConv.id
            _attachedFile.value = null
        }
    }

    fun setProvider(provider: AiProviderId) {
        _activeProvider.value = provider
        preferences.setActiveProvider(provider)
        val model = preferences.getModel(provider)
        _activeModel.value = model
    }

    fun setModel(model: String) {
        _activeModel.value = model
        preferences.setModel(_activeProvider.value, model)
    }

    fun setAttachedFile(file: AttachedFile?) {
        _attachedFile.value = file
    }

    fun removeAttachment() {
        _attachedFile.value = null
    }

    fun sendMessage(text: String) {
        val prompt = text.trim()
        val fileToSend = _attachedFile.value
        if ((prompt.isEmpty() && fileToSend == null) || _isLoading.value) return

        // Bersihkan lampiran dari input bar setelah dikirim
        _attachedFile.value = null

        viewModelScope.launch {
            _isLoading.value = true
            try {
                var convId = _currentConversationId.value
                if (convId == null) {
                    val newConv = repository.createNewConversation(
                        provider = _activeProvider.value,
                        model = _activeModel.value
                    )
                    convId = newConv.id
                    _currentConversationId.value = convId
                }

                repository.sendUserPrompt(
                    conversationId = convId,
                    prompt = prompt,
                    provider = _activeProvider.value,
                    model = _activeModel.value,
                    attachedFile = fileToSend
                )
            } catch (e: Exception) {
                _toastMessage.value = e.message ?: "Terjadi kesalahan"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun renameConversation(id: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameConversation(id, newTitle)
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversationById(id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            _currentConversationId.value = null
        }
    }

    fun deleteMessage(message: ChatMessage) {
        viewModelScope.launch {
            repository.deleteMessage(message)
        }
    }

    fun saveApiKeys(provider: AiProviderId, keys: List<String>) {
        preferences.setApiKeys(provider, keys)
    }

    fun addApiKey(provider: AiProviderId, key: String) {
        preferences.addApiKey(provider, key)
    }

    fun removeApiKey(provider: AiProviderId, key: String) {
        preferences.removeApiKey(provider, key)
    }

    fun saveEndpoint(provider: AiProviderId, endpoint: String) {
        preferences.setEndpoint(provider, endpoint)
    }

    suspend fun testApiKey(
        provider: AiProviderId,
        apiKey: String,
        model: String,
        endpoint: String
    ): Result<String> {
        return repository.aiService.testConnection(
            provider = provider,
            apiKey = apiKey,
            model = model,
            endpoint = endpoint
        )
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
