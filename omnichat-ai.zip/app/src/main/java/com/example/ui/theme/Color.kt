package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Slate / Charcoal Clean Palette (Non-Neon)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Calm, non-neon accent colors
val AccentBlue = Color(0xFF2563EB)
val AccentBlueLight = Color(0xFF3B82F6)
val AccentTeal = Color(0xFF0D9488)
val AccentMutedRed = Color(0xFFDC2626)
val AccentMutedGreen = Color(0xFF16A34A)

// Dark theme surface colors
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF283548)
val DarkBackground = Color(0xFF0F172A)
