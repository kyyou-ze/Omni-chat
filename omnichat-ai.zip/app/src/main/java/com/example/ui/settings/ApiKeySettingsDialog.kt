package com.example.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.ApiKeyPreferences
import com.example.data.model.AiProviderId
import com.example.data.model.AiProviders
import com.example.data.model.ProviderConfig
import com.example.ui.theme.AccentMutedGreen
import com.example.ui.theme.AccentMutedRed
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeySettingsDialog(
    preferences: ApiKeyPreferences,
    initialProvider: AiProviderId = AiProviderId.GEMINI,
    onDismiss: () -> Unit,
    onSaveAndApply: (provider: AiProviderId, model: String) -> Unit,
    onTestApiKey: suspend (provider: AiProviderId, key: String, model: String, endpoint: String) -> Result<String>
) {
    val providers = AiProviders.providers
    val initialIndex = providers.indexOfFirst { it.id == initialProvider }.coerceAtLeast(0)
    var selectedTabIndex by remember { mutableIntStateOf(initialIndex) }
    var systemPrompt by remember { mutableStateOf(preferences.getSystemPrompt()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "Pengaturan & Tumpukan Kunci API",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                "Bisa menumpuk banyak kunci (rotasi otomatis)",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate400)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_settings_button")) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Tab bar for providers
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    providers.forEachIndexed { index, provider ->
                        val keyCount = preferences.getApiKeys(provider.id).size
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (keyCount > 0) AccentMutedGreen else Slate400)
                                    )
                                    Text(
                                        provider.displayName + if (keyCount > 1) " ($keyCount)" else "",
                                        fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        )
                    }
                }

                val currentProvider = providers[selectedTabIndex]
                ProviderConfigSection(
                    provider = currentProvider,
                    preferences = preferences,
                    onSave = { keys, model, endpoint ->
                        preferences.setApiKeys(currentProvider.id, keys)
                        preferences.setModel(currentProvider.id, model)
                        preferences.setEndpoint(currentProvider.id, endpoint)
                        preferences.setSystemPrompt(systemPrompt)
                        onSaveAndApply(currentProvider.id, model)
                    },
                    onTest = { key, model, endpoint ->
                        onTestApiKey(currentProvider.id, key, model, endpoint)
                    },
                    systemPrompt = systemPrompt,
                    onSystemPromptChange = { systemPrompt = it }
                )
            }
        }
    }
}

@Composable
private fun ProviderConfigSection(
    provider: ProviderConfig,
    preferences: ApiKeyPreferences,
    onSave: (keys: List<String>, model: String, endpoint: String) -> Unit,
    onTest: suspend (key: String, model: String, endpoint: String) -> Result<String>,
    systemPrompt: String,
    onSystemPromptChange: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var keysList by remember(provider.id) { mutableStateOf(preferences.getApiKeys(provider.id)) }
    var newKeyInput by remember(provider.id) { mutableStateOf("") }
    var selectedModel by remember(provider.id) { mutableStateOf(preferences.getModel(provider.id)) }
    var endpoint by remember(provider.id) { mutableStateOf(preferences.getEndpoint(provider.id)) }

    var testStatus by remember(provider.id) { mutableStateOf<String?>(null) }
    var isTesting by remember(provider.id) { mutableStateOf(false) }
    var isSuccess by remember(provider.id) { mutableStateOf(false) }

    var showAdvanced by remember { mutableStateOf(false) }
    var isBulkInputMode by remember { mutableStateOf(false) }
    var bulkInputText by remember(provider.id) { mutableStateOf(keysList.joinToString("\n")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Provider Info Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "${provider.displayName} (${provider.company})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        val totalKeys = keysList.size
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (totalKeys > 0) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (totalKeys > 0) AccentMutedGreen else Slate400,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                if (totalKeys > 0) "$totalKeys Kunci Siap" else "Belum Ada Kunci",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (totalKeys > 0) AccentMutedGreen else Slate500
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        provider.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Dapatkan API Key di: ${provider.documentationUrl}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Multi-Key / Stacked API Keys Header & Explanation
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Layers, contentDescription = null, tint = Slate800, modifier = Modifier.size(18.dp))
                    Text(
                        "TUMPUKAN API KEY (${keysList.size})",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Slate800)
                    )
                }

                Text(
                    text = if (isBulkInputMode) "Mode Kartu" else "Mode Tempel Banyak (Baris Baru)",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.clickable {
                        if (isBulkInputMode) {
                            // Sync bulk to list
                            val parsed = bulkInputText.split("\n", ",", ";")
                                .map { it.trim() }
                                .filter { it.isNotEmpty() }
                            keysList = parsed
                        } else {
                            bulkInputText = keysList.joinToString("\n")
                        }
                        isBulkInputMode = !isBulkInputMode
                    }
                )
            }
            Text(
                "💡 Fitur Numpuk Kunci: Kamu bisa menambahkan beberapa API Key sekaligus. Bila kunci pertama terkena batas limit (Rate Limit 429 / kuota habis), aplikasi otomatis beralih ke kunci berikutnya tanpa memutus chat.",
                style = MaterialTheme.typography.labelSmall.copy(color = Slate500),
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        if (isBulkInputMode) {
            // Bulk Text Area Mode: paste multiple keys directly separated by line
            item {
                OutlinedTextField(
                    value = bulkInputText,
                    onValueChange = {
                        bulkInputText = it
                        keysList = it.split("\n", ",", ";")
                            .map { k -> k.trim() }
                            .filter { k -> k.isNotEmpty() }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bulk_api_key_input"),
                    placeholder = {
                        Text(
                            "Tempel beberapa API Key di sini (1 kunci per baris):\n${provider.keyPlaceholder}\n${provider.keyPlaceholder}_2",
                            color = Slate400,
                            fontSize = 12.sp
                        )
                    },
                    minLines = 4,
                    maxLines = 8,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
            }
        } else {
            // Add New Key Input Field
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newKeyInput,
                        onValueChange = { newKeyInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("new_api_key_field"),
                        placeholder = { Text("+ Tambah Kunci Baru (${provider.keyPlaceholder})", fontSize = 12.sp, color = Slate400) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Button(
                        onClick = {
                            val trimmed = newKeyInput.trim()
                            if (trimmed.isNotEmpty() && !keysList.contains(trimmed)) {
                                keysList = keysList + trimmed
                                newKeyInput = ""
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        enabled = newKeyInput.trim().isNotEmpty(),
                        modifier = Modifier.testTag("add_key_to_stack_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Slate800)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tumpuk", fontSize = 12.sp)
                    }
                }
            }

            // List of stacked keys
            if (keysList.isEmpty()) {
                item {
                    Text(
                        "Belum ada kunci tersimpan dalam tumpukan.",
                        style = MaterialTheme.typography.bodySmall.copy(color = Slate400, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            } else {
                itemsIndexed(keysList) { idx, keyItem ->
                    val masked = if (keyItem.length > 10) {
                        keyItem.take(6) + "••••••••" + keyItem.takeLast(4)
                    } else {
                        "••••••••"
                    }
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (idx == 0) Slate800 else Slate200)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        if (idx == 0) "Utama #1" else "Cadangan #${idx + 1}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (idx == 0) Color.White else Slate700,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Text(
                                    masked,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                    )
                                )
                            }

                            IconButton(
                                onClick = {
                                    keysList = keysList.filterIndexed { index, _ -> index != idx }
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Hapus Kunci",
                                    tint = AccentMutedRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Model Selection
        item {
            Text(
                "PILIH MODEL",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Slate500)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                provider.availableModels.forEach { m ->
                    FilterChip(
                        selected = selectedModel == m,
                        onClick = { selectedModel = m },
                        label = { Text(m, fontSize = 12.sp) },
                        modifier = Modifier.testTag("model_chip_$m")
                    )
                }
            }
        }

        // Action Buttons: Test Connection & Save
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val firstKey = keysList.firstOrNull() ?: newKeyInput.trim()
                        if (firstKey.isBlank()) {
                            testStatus = "Kunci API masih kosong!"
                            isSuccess = false
                            return@OutlinedButton
                        }
                        isTesting = true
                        testStatus = null
                        coroutineScope.launch {
                            val result = onTest(firstKey, selectedModel, endpoint)
                            isTesting = false
                            if (result.isSuccess) {
                                isSuccess = true
                                testStatus = "Koneksi Berhasil! Kunci API valid & siap digunakan."
                            } else {
                                isSuccess = false
                                testStatus = "Gagal: ${result.exceptionOrNull()?.message ?: "Koneksi bermasalah"}"
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("test_key_button"),
                    enabled = !isTesting,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Menguji...", fontSize = 13.sp)
                    } else {
                        Text("Tes Kunci", fontSize = 13.sp)
                    }
                }

                Button(
                    onClick = {
                        // Include newKeyInput if not added yet
                        val finalKeys = if (newKeyInput.isNotBlank() && !keysList.contains(newKeyInput.trim())) {
                            keysList + newKeyInput.trim()
                        } else {
                            keysList
                        }
                        onSave(finalKeys, selectedModel, endpoint)
                        testStatus = "Pengaturan & tumpukan kunci berhasil disimpan!"
                        isSuccess = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_settings_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Slate800)
                ) {
                    Text("Simpan Semua", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            AnimatedVisibility(visible = testStatus != null) {
                testStatus?.let { msg ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSuccess) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFFEE2E2)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isSuccess) AccentMutedGreen else AccentMutedRed,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // Advanced Options Toggle (Custom Endpoint & System Prompt)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAdvanced = !showAdvanced }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.Tune,
                        contentDescription = null,
                        tint = Slate500,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        "Opsi Lanjutan & Instruksi Sistem",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                    )
                }
                Text(
                    if (showAdvanced) "Tutup" else "Buka",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.secondary)
                )
            }
        }

        if (showAdvanced) {
            item {
                Text(
                    "CUSTOM ENDPOINT URL (Opsional)",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    textStyle = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    "INSTRUKSI SISTEM (Kepribadian AI)",
                    style = MaterialTheme.typography.labelSmall.copy(color = Slate500, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = onSystemPromptChange,
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    shape = RoundedCornerShape(8.dp),
                    textStyle = MaterialTheme.typography.bodySmall,
                    placeholder = { Text("Petunjuk umum untuk model AI...", style = MaterialTheme.typography.bodySmall) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "⚡ Ringan & Efisien: Seluruh rotasi kunci ditangani secara lokal tanpa server perantara, menjamin privasi dan performa maksimal.",
                style = MaterialTheme.typography.labelSmall.copy(color = Slate400),
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
    }
}
