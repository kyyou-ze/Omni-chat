package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.example.data.model.AttachedFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.math.max

object FileUtils {

    suspend fun processUri(context: Context, uri: Uri): AttachedFile? = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        var name = "file"
        var size: Long = 0

        // 1. Ambil nama & ukuran file
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: "file"
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {
        }

        val mimeType = contentResolver.getType(uri) ?: getMimeTypeFromName(name)
        val isImage = mimeType.startsWith("image/")

        if (isImage) {
            // Kompresi gambar agar ringan dan hemat memori (< 150KB)
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val originalBitmap = BitmapFactory.decodeStream(input) ?: return@withContext null
                    val maxDim = 1024
                    val width = originalBitmap.width
                    val height = originalBitmap.height

                    val scaledBitmap = if (width > maxDim || height > maxDim) {
                        val ratio = maxDim.toFloat() / max(width, height)
                        Bitmap.createScaledBitmap(
                            originalBitmap,
                            (width * ratio).toInt(),
                            (height * ratio).toInt(),
                            true
                        )
                    } else {
                        originalBitmap
                    }

                    val outputStream = ByteArrayOutputStream()
                    scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
                    val bytes = outputStream.toByteArray()
                    val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

                    return@withContext AttachedFile(
                        name = name,
                        mimeType = "image/jpeg",
                        sizeBytes = bytes.size.toLong(),
                        base64Data = base64,
                        isImage = true
                    )
                }
            } catch (e: Exception) {
                return@withContext null
            }
        } else {
            // Baca teks dokumen (maksimal 50KB agar tetap ringan dan hemat token)
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = ByteArray(50 * 1024)
                    val read = input.read(bytes)
                    if (read > 0) {
                        val text = String(bytes, 0, read, Charsets.UTF_8)
                        return@withContext AttachedFile(
                            name = name,
                            mimeType = mimeType,
                            sizeBytes = if (size > 0) size else read.toLong(),
                            textContent = text,
                            isImage = false
                        )
                    }
                }
            } catch (e: Exception) {
                return@withContext null
            }
        }
        null
    }

    private fun getMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "txt" -> "text/plain"
            "json" -> "application/json"
            "csv" -> "text/csv"
            "md" -> "text/markdown"
            "kt", "java", "py", "js", "ts", "html", "css", "c", "cpp" -> "text/plain"
            "pdf" -> "application/pdf"
            else -> "text/plain"
        }
    }
}
