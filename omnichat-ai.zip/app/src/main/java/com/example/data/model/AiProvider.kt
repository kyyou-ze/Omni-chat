package com.example.data.model

enum class AiProviderId(val key: String) {
    GEMINI("gemini"),
    CHATGPT("chatgpt"),
    CLAUDE("claude"),
    GROK("grok"),
    META("meta")
}

data class ProviderConfig(
    val id: AiProviderId,
    val displayName: String,
    val company: String,
    val defaultModel: String,
    val availableModels: List<String>,
    val defaultEndpoint: String,
    val keyPlaceholder: String,
    val documentationUrl: String,
    val description: String
)

object AiProviders {
    val providers: List<ProviderConfig> = listOf(
        ProviderConfig(
            id = AiProviderId.GEMINI,
            displayName = "Gemini",
            company = "Google",
            defaultModel = "gemini-1.5-flash",
            availableModels = listOf("gemini-1.5-flash", "gemini-1.5-pro", "gemini-2.0-flash"),
            defaultEndpoint = "https://generativelanguage.googleapis.com/v1beta/models/",
            keyPlaceholder = "AIzaSy...",
            documentationUrl = "aistudio.google.com/apikey",
            description = "Respon super cepat, kuota gratis besar, optimal untuk penggunaan sehari-hari."
        ),
        ProviderConfig(
            id = AiProviderId.CHATGPT,
            displayName = "ChatGPT",
            company = "OpenAI",
            defaultModel = "gpt-4o-mini",
            availableModels = listOf("gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"),
            defaultEndpoint = "https://api.openai.com/v1/chat/completions",
            keyPlaceholder = "sk-...",
            documentationUrl = "platform.openai.com/api-keys",
            description = "Model penalaran andal dan populer dari OpenAI."
        ),
        ProviderConfig(
            id = AiProviderId.CLAUDE,
            displayName = "Claude",
            company = "Anthropic",
            defaultModel = "claude-3-5-haiku-20241022",
            availableModels = listOf("claude-3-5-haiku-20241022", "claude-3-5-sonnet-20241022", "claude-3-haiku-20240307"),
            defaultEndpoint = "https://api.anthropic.com/v1/messages",
            keyPlaceholder = "sk-ant-...",
            documentationUrl = "console.anthropic.com/settings/keys",
            description = "Gaya bahasa sangat natural, teliti, dan cerdas."
        ),
        ProviderConfig(
            id = AiProviderId.GROK,
            displayName = "Grok",
            company = "xAI",
            defaultModel = "grok-2-latest",
            availableModels = listOf("grok-2-latest", "grok-beta"),
            defaultEndpoint = "https://api.x.ai/v1/chat/completions",
            keyPlaceholder = "xai-...",
            documentationUrl = "console.x.ai",
            description = "AI dari xAI dengan perspektif lugas dan informasi terkini."
        ),
        ProviderConfig(
            id = AiProviderId.META,
            displayName = "Meta Llama",
            company = "Meta (via Groq/OpenRouter)",
            defaultModel = "llama-3.3-70b-versatile",
            availableModels = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "meta-llama/llama-3.3-70b-instruct"),
            defaultEndpoint = "https://api.groq.com/openai/v1/chat/completions",
            keyPlaceholder = "gsk_... atau sk-or-...",
            documentationUrl = "console.groq.com/keys",
            description = "Model open-weights Llama 3 terbaru dengan inferensi ultra-cepat melalui Groq."
        )
    )

    fun get(id: AiProviderId): ProviderConfig =
        providers.firstOrNull { it.id == id } ?: providers.first()

    fun getByKey(key: String): ProviderConfig =
        providers.firstOrNull { it.id.key.equals(key, ignoreCase = true) } ?: providers.first()
}
