package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.example.data.model.AiProviderId
import com.example.data.model.AiProviders

class ApiKeyPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("omni_ai_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PREFIX = "api_key_"
        private const val MODEL_PREFIX = "model_"
        private const val ENDPOINT_PREFIX = "endpoint_"
        private const val KEY_ACTIVE_PROVIDER = "active_provider"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val DEFAULT_SYSTEM_PROMPT =
            "Kamu adalah asisten AI yang ramah, cerdas, dan membantu. Berikan jawaban yang akurat, jelas, dan terstruktur rapi."
    }

    /**
     * Mengambil daftar tumpukan API Key untuk penyedia tertentu.
     * Pengguna dapat menumpuk banyak kunci (dipisahkan baris baru / newline).
     */
    fun getApiKeys(provider: AiProviderId): List<String> {
        val raw = prefs.getString(KEY_PREFIX + provider.key, "")?.trim() ?: ""
        val keys = raw.split("\n", ",", ";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (keys.isNotEmpty()) return keys

        // Fallback untuk Gemini jika ada di BuildConfig Secrets panel
        if (provider == AiProviderId.GEMINI) {
            try {
                val buildConfigKey = BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
                if (!buildConfigKey.isNullOrBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
                    return listOf(buildConfigKey.trim())
                }
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    /**
     * Mengambil API Key utama/pertama dari tumpukan.
     */
    fun getApiKey(provider: AiProviderId): String {
        return getApiKeys(provider).firstOrNull() ?: ""
    }

    /**
     * Menyimpan satu atau banyak API Key (dipisah baris baru).
     */
    fun setApiKey(provider: AiProviderId, rawKeys: String) {
        val cleaned = rawKeys.split("\n", ",", ";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
        prefs.edit().putString(KEY_PREFIX + provider.key, cleaned).apply()
    }

    /**
     * Menyimpan daftar list tumpukan API Key.
     */
    fun setApiKeys(provider: AiProviderId, keys: List<String>) {
        val joined = keys.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
        prefs.edit().putString(KEY_PREFIX + provider.key, joined).apply()
    }

    /**
     * Menambah satu kunci baru ke tumpukan.
     */
    fun addApiKey(provider: AiProviderId, newKey: String) {
        val trimmed = newKey.trim()
        if (trimmed.isEmpty()) return
        val current = getApiKeys(provider).toMutableList()
        if (!current.contains(trimmed)) {
            current.add(trimmed)
            setApiKeys(provider, current)
        }
    }

    /**
     * Menghapus salah satu kunci dari tumpukan.
     */
    fun removeApiKey(provider: AiProviderId, keyToRemove: String) {
        val current = getApiKeys(provider).filter { it != keyToRemove.trim() }
        setApiKeys(provider, current)
    }

    fun hasApiKey(provider: AiProviderId): Boolean {
        return getApiKeys(provider).isNotEmpty()
    }

    fun getModel(provider: AiProviderId): String {
        val defaultModel = AiProviders.get(provider).defaultModel
        return prefs.getString(MODEL_PREFIX + provider.key, defaultModel) ?: defaultModel
    }

    fun setModel(provider: AiProviderId, model: String) {
        prefs.edit().putString(MODEL_PREFIX + provider.key, model.trim()).apply()
    }

    fun getEndpoint(provider: AiProviderId): String {
        val defaultEndpoint = AiProviders.get(provider).defaultEndpoint
        return prefs.getString(ENDPOINT_PREFIX + provider.key, defaultEndpoint) ?: defaultEndpoint
    }

    fun setEndpoint(provider: AiProviderId, endpoint: String) {
        prefs.edit().putString(ENDPOINT_PREFIX + provider.key, endpoint.trim()).apply()
    }

    fun getActiveProvider(): AiProviderId {
        val key = prefs.getString(KEY_ACTIVE_PROVIDER, AiProviderId.GEMINI.key) ?: AiProviderId.GEMINI.key
        return try {
            AiProviderId.valueOf(key.uppercase())
        } catch (_: Exception) {
            AiProviders.getByKey(key).id
        }
    }

    fun setActiveProvider(provider: AiProviderId) {
        prefs.edit().putString(KEY_ACTIVE_PROVIDER, provider.key).apply()
    }

    fun getSystemPrompt(): String {
        return prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
    }

    fun setSystemPrompt(prompt: String) {
        prefs.edit().putString(KEY_SYSTEM_PROMPT, prompt).apply()
    }
}
