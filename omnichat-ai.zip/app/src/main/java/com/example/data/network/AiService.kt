package com.example.data.network

import com.example.data.model.AiProviderId
import com.example.data.model.AttachedFile
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class AiService {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Mengirim pesan dengan dukungan tumpukan API Key (otomatis rotasi failover jika terkena rate limit 429/401/403)
     * serta dukungan upload file/gambar.
     */
    suspend fun sendMessageWithKeyPool(
        provider: AiProviderId,
        apiKeys: List<String>,
        model: String,
        endpoint: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        prompt: String,
        attachedFile: AttachedFile? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val validKeys = apiKeys.filter { it.isNotBlank() }
        if (validKeys.isEmpty()) {
            return@withContext Result.failure(
                IllegalArgumentException("Belum ada API Key untuk ${provider.name}. Silakan masukkan satu atau tumpuk beberapa API Key di Pengaturan.")
            )
        }

        var lastError: Throwable = Exception("Gagal menghubungi ${provider.name}")

        // Mencoba setiap kunci yang ditumpuk secara berurutan jika terjadi error rate-limit atau quota
        for ((index, currentKey) in validKeys.withIndex()) {
            val result = try {
                when (provider) {
                    AiProviderId.GEMINI -> callGemini(currentKey, model, systemPrompt, history, prompt, attachedFile)
                    AiProviderId.CHATGPT,
                    AiProviderId.GROK,
                    AiProviderId.META -> callOpenAiFormat(endpoint, currentKey, model, systemPrompt, history, prompt, attachedFile)
                    AiProviderId.CLAUDE -> callClaude(currentKey, model, systemPrompt, history, prompt, attachedFile)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }

            if (result.isSuccess) {
                return@withContext result
            } else {
                lastError = result.exceptionOrNull() ?: lastError
                // Jika masih ada kunci cadangan di tumpukan dan error berkaitan dengan kuota / rate limit (429, 401, 403)
                val errMsg = lastError.message.orEmpty()
                val isRecoverable = errMsg.contains("429") || errMsg.contains("401") || errMsg.contains("403") ||
                        errMsg.contains("rate", ignoreCase = true) || errMsg.contains("quota", ignoreCase = true)

                if (isRecoverable && index < validKeys.size - 1) {
                    // Lanjut coba kunci berikutnya di tumpukan
                    continue
                } else if (!isRecoverable) {
                    // Error bukan karena kunci (misal koneksi terputus total)
                    return@withContext result
                }
            }
        }

        val total = validKeys.size
        val summaryMsg = if (total > 1) {
            "Semua $total kunci API pada tumpukan telah dicoba, kendala: ${lastError.message}"
        } else {
            lastError.message ?: "Gagal memproses pesan"
        }
        Result.failure(Exception(summaryMsg, lastError))
    }

    suspend fun testConnection(
        provider: AiProviderId,
        apiKey: String,
        model: String,
        endpoint: String
    ): Result<String> = withContext(Dispatchers.IO) {
        sendMessageWithKeyPool(
            provider = provider,
            apiKeys = listOf(apiKey),
            model = model,
            endpoint = endpoint,
            systemPrompt = "Jawab hanya 1 kata: 'Koneksi Berhasil'",
            history = emptyList(),
            prompt = "Tes koneksi API."
        )
    }

    private fun callGemini(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        prompt: String,
        attachedFile: AttachedFile?
    ): Result<String> {
        val cleanModel = model.ifBlank { "gemini-1.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=$apiKey"

        val rootJson = JSONObject()

        if (systemPrompt.isNotBlank()) {
            val systemObj = JSONObject()
            val sysParts = JSONArray().put(JSONObject().put("text", systemPrompt))
            systemObj.put("parts", sysParts)
            rootJson.put("systemInstruction", systemObj)
        }

        val contentsArray = JSONArray()
        val trimmedHistory = history.takeLast(10)
        for (msg in trimmedHistory) {
            if (msg.role == "user" || msg.role == "assistant") {
                val role = if (msg.role == "assistant") "model" else "user"
                val partObj = JSONObject().put("text", msg.content)
                val item = JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(partObj))
                contentsArray.put(item)
            }
        }

        // Current prompt with potential file/image attachment
        val currentPromptParts = JSONArray()

        if (attachedFile != null) {
            if (attachedFile.isImage && !attachedFile.base64Data.isNullOrBlank()) {
                val inlineData = JSONObject()
                    .put("mimeType", attachedFile.mimeType)
                    .put("data", attachedFile.base64Data)
                currentPromptParts.put(JSONObject().put("inlineData", inlineData))
            } else if (!attachedFile.textContent.isNullOrBlank()) {
                val docText = "\n\n[Lampiran Dokumen: ${attachedFile.name}]\n${attachedFile.textContent}\n"
                currentPromptParts.put(JSONObject().put("text", docText))
            }
        }

        currentPromptParts.put(JSONObject().put("text", prompt))

        val currentPromptItem = JSONObject()
            .put("role", "user")
            .put("parts", currentPromptParts)
        contentsArray.put(currentPromptItem)

        rootJson.put("contents", contentsArray)

        val request = Request.Builder()
            .url(url)
            .post(rootJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorMsg = parseErrorMessage(responseBody, response.code)
                return Result.failure(IOException("Gemini Error (${response.code}): $errorMsg"))
            }

            val resJson = JSONObject(responseBody)
            val candidates = resJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return Result.failure(IOException("Tidak ada respon dari Gemini."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val contentObj = firstCandidate.optJSONObject("content")
            val parts = contentObj?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")

            if (text.isNullOrBlank()) {
                val finishReason = firstCandidate.optString("finishReason", "UNKNOWN")
                return Result.failure(IOException("Respon kosong (Alasan: $finishReason)."))
            }

            return Result.success(text.trim())
        }
    }

    private fun callOpenAiFormat(
        endpoint: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        prompt: String,
        attachedFile: AttachedFile?
    ): Result<String> {
        val rootJson = JSONObject()
        rootJson.put("model", model)

        val messagesArray = JSONArray()

        if (systemPrompt.isNotBlank()) {
            messagesArray.put(
                JSONObject()
                    .put("role", "system")
                    .put("content", systemPrompt)
            )
        }

        val trimmedHistory = history.takeLast(10)
        for (msg in trimmedHistory) {
            if (msg.role == "user" || msg.role == "assistant") {
                messagesArray.put(
                    JSONObject()
                        .put("role", msg.role)
                        .put("content", msg.content)
                )
            }
        }

        val userMessageObj = JSONObject().put("role", "user")

        if (attachedFile != null && attachedFile.isImage && !attachedFile.base64Data.isNullOrBlank()) {
            // Multimodal content array
            val partsArray = JSONArray()
            partsArray.put(JSONObject().put("type", "text").put("text", prompt))
            val imgUrlObj = JSONObject()
                .put("url", "data:${attachedFile.mimeType};base64,${attachedFile.base64Data}")
            partsArray.put(JSONObject().put("type", "image_url").put("image_url", imgUrlObj))
            userMessageObj.put("content", partsArray)
        } else if (attachedFile != null && !attachedFile.textContent.isNullOrBlank()) {
            val enrichedPrompt = "$prompt\n\n[Lampiran File: ${attachedFile.name}]\n${attachedFile.textContent}"
            userMessageObj.put("content", enrichedPrompt)
        } else {
            userMessageObj.put("content", prompt)
        }

        messagesArray.put(userMessageObj)
        rootJson.put("messages", messagesArray)

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(rootJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorMsg = parseErrorMessage(responseBody, response.code)
                return Result.failure(IOException("API Error (${response.code}): $errorMsg"))
            }

            val resJson = JSONObject(responseBody)
            val choices = resJson.optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                return Result.failure(IOException("Tidak ada respon teks dalam output API."))
            }

            val messageObj = choices.getJSONObject(0).optJSONObject("message")
            val content = messageObj?.optString("content")

            if (content.isNullOrBlank()) {
                return Result.failure(IOException("Respon dari model kosong."))
            }

            return Result.success(content.trim())
        }
    }

    private fun callClaude(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        prompt: String,
        attachedFile: AttachedFile?
    ): Result<String> {
        val url = "https://api.anthropic.com/v1/messages"
        val rootJson = JSONObject()
        rootJson.put("model", model)
        rootJson.put("max_tokens", 2048)

        if (systemPrompt.isNotBlank()) {
            rootJson.put("system", systemPrompt)
        }

        val messagesArray = JSONArray()
        val trimmedHistory = history.takeLast(10)
        for (msg in trimmedHistory) {
            if (msg.role == "user" || msg.role == "assistant") {
                messagesArray.put(
                    JSONObject()
                        .put("role", msg.role)
                        .put("content", msg.content)
                )
            }
        }

        val userMessageObj = JSONObject().put("role", "user")

        if (attachedFile != null && attachedFile.isImage && !attachedFile.base64Data.isNullOrBlank()) {
            val contentParts = JSONArray()
            val imgSource = JSONObject()
                .put("type", "base64")
                .put("media_type", "image/jpeg")
                .put("data", attachedFile.base64Data)
            val imgPart = JSONObject()
                .put("type", "image")
                .put("source", imgSource)
            contentParts.put(imgPart)
            contentParts.put(JSONObject().put("type", "text").put("text", prompt))
            userMessageObj.put("content", contentParts)
        } else if (attachedFile != null && !attachedFile.textContent.isNullOrBlank()) {
            val fullPrompt = "$prompt\n\n[Lampiran File: ${attachedFile.name}]\n${attachedFile.textContent}"
            userMessageObj.put("content", fullPrompt)
        } else {
            userMessageObj.put("content", prompt)
        }

        messagesArray.put(userMessageObj)
        rootJson.put("messages", messagesArray)

        val request = Request.Builder()
            .url(url)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .post(rootJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorMsg = parseErrorMessage(responseBody, response.code)
                return Result.failure(IOException("Claude Error (${response.code}): $errorMsg"))
            }

            val resJson = JSONObject(responseBody)
            val contentArray = resJson.optJSONArray("content")
            if (contentArray == null || contentArray.length() == 0) {
                return Result.failure(IOException("Tidak ada respon dari Claude."))
            }

            val text = contentArray.getJSONObject(0).optString("text")
            if (text.isNullOrBlank()) {
                return Result.failure(IOException("Respon Claude kosong."))
            }

            return Result.success(text.trim())
        }
    }

    private fun parseErrorMessage(rawJson: String, statusCode: Int): String {
        return try {
            val json = JSONObject(rawJson)
            if (json.has("error")) {
                val errorVal = json.get("error")
                if (errorVal is JSONObject) {
                    errorVal.optString("message", rawJson)
                } else {
                    errorVal.toString()
                }
            } else if (json.has("message")) {
                json.getString("message")
            } else {
                "HTTP $statusCode: $rawJson"
            }
        } catch (_: Exception) {
            when (statusCode) {
                401 -> "Kunci API tidak valid atau telah kedaluwarsa (401 Unauthorized)."
                403 -> "Akses ditolak atau izin akun tidak mencukupi (403 Forbidden)."
                429 -> "Batas kuota / rate limit tercapai (429 Too Many Requests)."
                500, 502, 503 -> "Server penyedia AI sedang mengalami gangguan. Coba sesaat lagi."
                else -> "Gagal memproses permintaan (Kode $statusCode)."
            }
        }
    }
}
