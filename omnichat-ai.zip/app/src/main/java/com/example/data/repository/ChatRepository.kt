package com.example.data.repository

import com.example.data.local.ApiKeyPreferences
import com.example.data.local.ConversationDao
import com.example.data.local.MessageDao
import com.example.data.model.AiProviderId
import com.example.data.model.AiProviders
import com.example.data.model.AttachedFile
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.network.AiService
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ChatRepository(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    val preferences: ApiKeyPreferences,
    val aiService: AiService = AiService()
) {
    fun getAllConversations(): Flow<List<Conversation>> =
        conversationDao.getAllConversations()

    fun getMessages(conversationId: String): Flow<List<ChatMessage>> =
        messageDao.getMessagesForConversation(conversationId)

    suspend fun createNewConversation(
        provider: AiProviderId,
        model: String,
        title: String = "Percakapan Baru"
    ): Conversation {
        val conversation = Conversation(
            id = UUID.randomUUID().toString(),
            title = title,
            providerKey = provider.key,
            modelKey = model
        )
        conversationDao.insert(conversation)
        return conversation
    }

    suspend fun renameConversation(conversationId: String, newTitle: String) {
        conversationDao.updateTitle(conversationId, newTitle.trim())
    }

    suspend fun deleteConversation(conversation: Conversation) {
        conversationDao.delete(conversation)
    }

    suspend fun deleteConversationById(id: String) {
        conversationDao.deleteById(id)
    }

    suspend fun clearAllHistory() {
        conversationDao.deleteAll()
    }

    suspend fun deleteMessage(message: ChatMessage) {
        messageDao.delete(message)
    }

    suspend fun sendUserPrompt(
        conversationId: String,
        prompt: String,
        provider: AiProviderId,
        model: String,
        attachedFile: AttachedFile? = null
    ): Result<ChatMessage> {
        val trimmedPrompt = prompt.trim()
        if (trimmedPrompt.isEmpty() && attachedFile == null) {
            return Result.failure(IllegalArgumentException("Pesan atau lampiran tidak boleh kosong"))
        }

        val effectivePrompt = if (trimmedPrompt.isNotEmpty()) trimmedPrompt else "Tolong analisis file terlampir ini."

        // 1. Insert user message with attachment details
        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = "user",
            content = effectivePrompt,
            providerKey = provider.key,
            modelKey = model,
            timestamp = System.currentTimeMillis(),
            attachmentName = attachedFile?.name,
            attachmentType = if (attachedFile?.isImage == true) "image" else if (attachedFile != null) "file" else null
        )
        messageDao.insert(userMessage)

        // Update conversation title if default
        val existingHistory = messageDao.getMessagesList(conversationId)
        if (existingHistory.size <= 1) {
            val autoTitle = if (attachedFile != null) {
                "Analisis: ${attachedFile.name.take(20)}"
            } else if (effectivePrompt.length > 30) {
                effectivePrompt.take(27) + "..."
            } else {
                effectivePrompt
            }
            conversationDao.updateTitle(conversationId, autoTitle)
        } else {
            conversationDao.touch(conversationId)
        }

        // 2. Fetch stacked API keys & configuration
        val apiKeys = preferences.getApiKeys(provider)
        val endpoint = preferences.getEndpoint(provider)
        val systemPrompt = preferences.getSystemPrompt()

        if (apiKeys.isEmpty()) {
            val errorMsg = "Kunci API untuk ${AiProviders.get(provider).displayName} belum diatur. Buka Pengaturan untuk memasukkan API Key."
            val assistantError = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = "assistant",
                content = "⚠️ $errorMsg",
                providerKey = provider.key,
                modelKey = model,
                timestamp = System.currentTimeMillis()
            )
            messageDao.insert(assistantError)
            return Result.failure(IllegalStateException(errorMsg))
        }

        // 3. Make lightweight network request with automatic key rotation and file upload
        val apiResult = aiService.sendMessageWithKeyPool(
            provider = provider,
            apiKeys = apiKeys,
            model = model,
            endpoint = endpoint,
            systemPrompt = systemPrompt,
            history = existingHistory,
            prompt = effectivePrompt,
            attachedFile = attachedFile
        )

        return if (apiResult.isSuccess) {
            val replyText = apiResult.getOrThrow()
            val assistantMessage = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = "assistant",
                content = replyText,
                providerKey = provider.key,
                modelKey = model,
                timestamp = System.currentTimeMillis()
            )
            messageDao.insert(assistantMessage)
            conversationDao.touch(conversationId)
            Result.success(assistantMessage)
        } else {
            val exception = apiResult.exceptionOrNull() ?: Exception("Gagal menghubungi penyedia AI")
            val failureText = "⚠️ Terjadi Kendala: ${exception.message}"
            val assistantError = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = "assistant",
                content = failureText,
                providerKey = provider.key,
                modelKey = model,
                timestamp = System.currentTimeMillis()
            )
            messageDao.insert(assistantError)
            conversationDao.touch(conversationId)
            Result.failure(exception)
        }
    }
}
