package com.example.data.model

data class AttachedFile(
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val textContent: String? = null,
    val base64Data: String? = null,
    val isImage: Boolean = false
) {
    val formattedSize: String
        get() {
            return when {
                sizeBytes < 1024 -> "$sizeBytes B"
                sizeBytes < 1024 * 1024 -> "${sizeBytes / 1024} KB"
                else -> String.format(java.util.Locale.US, "%.1f MB", sizeBytes.toDouble() / (1024 * 1024))
            }
        }
}
